#ifndef MODEL_H
#define MODEL_H

#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>

struct Vertex
{
    float x,y,z;
};

// 定义原本的顶点数据结构
struct OriginVertex{
    Vertex location;
    Vertex normal;
    int id;
    int n;//由此点为起点的有向边数量
};

// 定义新增的顶点数据结构
struct NewVertex{
    Vertex location;
    int vertexA, vertexB;
    int faceA, faceB;
    int id;
};

// 定义有向边数据结构
struct DirectedEdge {
    int startVertexID;
    Vertex startLoac;
    int endVertexID;
    Vertex endLoac;
    int id;
    int otherHalfID;
    int faceID;
};

// 面
struct Face {
    int vertexA, vertexB, vertexC;
    int id;
};

// 定义模型类
class Model {
public:
    std::vector<OriginVertex> oriVertices;    
    std::vector<DirectedEdge> directedEdges;
    std::vector<Face> faces;


    // 从文件加载模型数据
    void loadModel(const std::string& filename);

    // Loop细分
    void loopSubdivision();

    // 输出结果
    void outPutResult(const std::string& filename);

    // 将结果储存并赋值给原有的vector里面
    void cleanAndStoreValue();

    //检查精度是否有问题
    void checkResult();

    Vertex CenterPoint(Vertex A, Vertex B);//求中点
    Vertex SumPoint(Vertex A, Vertex B);   // +
    Vertex SubPoint(Vertex A, Vertex B);   // -
    Vertex DivPoint(Vertex A, float d);    // /
    Vertex MulPoint(Vertex A, float m);    // *
};

#endif // MODEL_H