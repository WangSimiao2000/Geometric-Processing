To compile:

module add legacy-eng
qmake -project QT+=opengl
qmake
make

